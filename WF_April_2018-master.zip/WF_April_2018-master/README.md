# WF_April_2018
Practice contributing to an open source project!

1. FORK this repo. You will then have your own WF_April_2018 repo.

2. CLONE your WF_April_2018 repo into your local machine. DO NOT clone it into an existing git repo!!!!

3. Navigate into the WF_April_2018 project in your local machine and add your own directory. Name it with your group team name.

4. Add an html document of your choosing to your directory.

5. Navigate back up to the WF_April_2018 if you're not already there.

6. Git add.

7. Git commit.

8. Git push.

9. Submit a PULL REQUEST to me.
